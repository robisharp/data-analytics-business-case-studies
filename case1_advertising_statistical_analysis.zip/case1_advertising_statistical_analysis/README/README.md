🏷️ Case Title: Advertising Statistical Analysis 

📊 Business Problem 

A company invests in TV, Radio, and Newspaper advertising, but management is unsure: 
          Which channel contributes most to sales? 
          Where should they increase or reduce budget? 
          How to maximize ROI using data? 
They want a data-driven decision model instead of guesswork. 

🎯 Business Objective 
Identify the most effective advertising channel Measure relationship between ad spend and sales Build a predictive model for sales forecasting Provide budget allocation recommendations 

📁 Dataset Description Source: 
Advertising Dataset Columns: Column Description TV Advertising spend on TV (in $000) Radio Advertising spend on Radio (in $000) Newspaper Advertising spend on Newspaper (in $000) Sales Product sales (in $000 units) 

🛠 Tools & Technologies

- Microsoft Excel
- Statistical Analysis (Correlation, Regression, ANOVA)
- Data Visualization

🧹 Data Cleaning & Preparation Verified no missing values Checked data types and consistency Ensured numerical formatting Validated outliers using descriptive statistics 

👉 Dataset was clean and ready for analysis 

📈 Exploratory Data Analysis (EDA) From descriptive statistics & correlation analysis: 

1️⃣ TV vs Sales Strong positive correlation TV advertising has highest impact on sales 
2️⃣ Radio vs Sales Moderate positive correlation Good secondary marketing channel 
3️⃣ Newspaper vs Sales Weak correlation Least effective channel 

📊 Correlation Summary Channel Correlation with Sales TV High Radio Moderate Newspaper Low 

📐 Regression Analysis (Key Findings) 

regression sheet shows: 

Sales Prediction Equation: Sales = a + b1(TV) + b2(Radio) + b3(Newspaper) 

Key results: TV coefficient is highest Radio is significant Newspaper has very low impact 

👉 Model confirms: TV + Radio = Primary Sales Drivers 

🔍 Key Insights TV advertising drives maximum sales growth Radio is a strong supporting channel Newspaper advertising has minimal ROI Increasing TV spend significantly boosts revenue Reducing newspaper spend does not reduce sales much 

💡 Business Recommendations 

📌 Budget Reallocation Strategy Channel Recommendation TV Increase budget (High ROI) Radio Maintain / slightly increase Newspaper Reduce spending 
📌 Marketing Strategy Focus on TV + Radio integrated campaigns Reduce newspaper dependency Invest savings into digital + TV promotions 
📈 Expected Business Impact Higher sales growth Better marketing ROI Optimized advertising spend Data-driven marketing decisions 

🏁 Conclusion 

This analysis proves that: TV advertising is the most effective driver of sales, followed by radio. Newspaper advertising provides minimal contribution and can be reduced. This data-driven approach helps management optimize marketing budgets and maximize profitability. 